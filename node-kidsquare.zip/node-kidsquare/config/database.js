module.exports = {

	// the database url to connect
	url :  'mongodb://heroku_kf63r333:kj63bd0evrh8a5tb9pnp22optr@ds035553.mongolab.com:35553/heroku_kf63r333'
	// url : 'mongodb://localhost/kidsquare'
}
