angular.module('admin-state', [
  'admin-state.service',
  'admin-state.controller'
  ])
.config(function($stateProvider, $urlRouterProvider) {
  $urlRouterProvider.otherwise('/login');
     $stateProvider
      // HOME STATES AND NESTED VIEWS ========================================
      .state('admin', {
        url: '/menu-admin',
        templateUrl: 'admin/views/admin-dashboard.html',
        controller: 'menuAdminCtrl'
      })
});
