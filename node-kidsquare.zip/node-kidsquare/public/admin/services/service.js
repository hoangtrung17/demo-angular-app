var app = angular.module('admin-state.service',[]);

  app.factory('AdminDasboard', ['$http', '$rootScope',function($http, $rootScope) {
    return {
      getUser : function(id) {
        return $http.get('/users/' + id);
      },
      updateRole : function(event, id) {
        return $http.post('/setrole/' + id, event);
      }
    }
  }]);