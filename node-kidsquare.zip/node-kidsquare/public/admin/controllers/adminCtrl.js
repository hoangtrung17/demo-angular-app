var app = angular.module('admin-state.controller',[]);

  app.controller('menuAdminCtrl',['$scope', 'AdminDasboard', '$state', '$rootScope', function ($scope, AdminDasboard, $state, $rootScope) {
    if(!$rootScope.user) {
      $state.go('login');
    }

    AdminDasboard.getUser($rootScope.user._id)
      .success(function(data) {
        $scope.users = data;
      });

    $scope.updateMenber = function(userUpdate) {
      if(!userUpdate.local.isVIP) {
        userUpdate.local.isMember = !userUpdate.local.isMember;
        if (userUpdate) {
          AdminDasboard.updateRole(userUpdate, $rootScope.user._id)
            .success(function(data) {
              $scope.users = data;
            });
        }
      } else {
        alert("Không thể huỷ quyền member cho user Vip");
      }
    };

    $scope.updateVip = function(userUpdate) {
      if(!userUpdate.local.isImplement) {
        userUpdate.local.isVIP = !userUpdate.local.isVIP;
        if(userUpdate.local.isVIP) {
          userUpdate.local.isMember = true;
        }
        if (userUpdate) {
          AdminDasboard.updateRole(userUpdate, $rootScope.user._id)
            .success(function(data) {
              $scope.users = data;
            });
        }
      } else {
        alert("Không thể huỷ quyền Vip cho user Implement");
      }
    };

    $scope.updateImplement = function(userUpdate) {
      if(!userUpdate.local.isMod) {
        userUpdate.local.isImplement = !userUpdate.local.isImplement;
        if (userUpdate.local.isImplement) {
          userUpdate.local.isMember = true;
          userUpdate.local.isVIP = true;
        }
        if (userUpdate) {
          AdminDasboard.updateRole(userUpdate, $rootScope.user._id)
            .success(function(data) {
              $scope.users = data;
            });
        }
      } else {
        alert("Không thể huỷ quyền Implement cho user Mod");
      }
    };

    $scope.updateMod = function(userUpdate) {
      userUpdate.local.isMod = !userUpdate.local.isMod;
      if(userUpdate.local.isMod) {
        userUpdate.local.isMember = true;
        userUpdate.local.isVIP = true;
        userUpdate.local.isImplement = true;
      }
      if (userUpdate) {
        AdminDasboard.updateRole(userUpdate, $rootScope.user._id)
          .success(function(data) {
            $scope.users = data;
          });
      }
    };

  }]);