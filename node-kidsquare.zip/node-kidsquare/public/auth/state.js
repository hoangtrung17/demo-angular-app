angular.module('auth-state', [
  'auth-state.service',
  'auth-state.controller'
  ])
.config(function($stateProvider, $urlRouterProvider) {
	$urlRouterProvider.otherwise('/login');
     $stateProvider
      // HOME STATES AND NESTED VIEWS ========================================
      .state('login', {
          url: '/login',
          templateUrl: 'auth/login.html',
          controller: 'loginController'
      })

      // nested list with custom controller
      .state('register', {
          url: '/register',
          templateUrl: 'auth/register.html',
          controller: 'SignupController'
      })
      .state('forgot', {
        url: '/forgot',
        templateUrl: 'auth/forgot.html',
        controller: 'ForgotCtrl'
      })
});

