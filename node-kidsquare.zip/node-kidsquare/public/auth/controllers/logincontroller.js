var app = angular.module('auth-state.controller',[]);

  app.controller('loginController', ['$scope', '$rootScope', '$http','Auth', '$state', '$cookieStore', 'facebookService', function($scope, $rootScope, $http, Auth, $state, $cookieStore, facebookService) {

    $scope.err = null;
    if($rootScope.user) {
      $state.go('home');
    }

    $scope.login = function () {
      Auth.login($scope.user);
    }

    $scope.loginFacebook = function () {
      facebookService.getInfo()
        .then(function(response) {
          if(response.error) {
            alert(response.error.message+'!');
          } else {
            var user = {};
            user.name = response.first_name + ' ' + response.last_name;
            user.email = response.email;
            user.isFacebookAccount = true;
            Auth.loginFacebook(user);
          }
        }
      );
    }

    $rootScope.$on('authenticated', function() {
      $rootScope.Auth = Auth;
      $rootScope.user = Auth.user;
      $cookieStore.put('globals', Auth.user);
      $cookieStore.put('token', Auth.token);
      $state.go('home');
    });

    $rootScope.$on('authenticate-false', function() {
      $scope.err = Auth.err;
    });

  }]);

  app.controller('SignupController', ['$scope', '$rootScope', '$http','Auth', '$state', function($scope, $rootScope, $http, Auth, $state) {
    $scope.err = null;
    if($rootScope.user) {
      $state.go('home');
    }
    $scope.signup = function () {
      if($scope.user.password === $scope.password) {
        Auth.regiter($scope.user)
        .success(function(data) {
          if(data.code ==1) {
            $rootScope.user = data.user;
            $state.go('home');
          } else {
            $scope.err = data.message;
          }
        });
      } else {
        $scope.err = "Password not match";
      }
    }
  }]);

  app.controller('ForgotCtrl', ['$scope', '$rootScope', '$http','Auth', '$state', function($scope, $rootScope, $http, Auth, $state) {
    $scope.err = null;
    $scope.success = null;
    if($rootScope.user) {
      $state.go('home');
    }

    $scope.forgot = function () {
      Auth.forgot($scope.email)
      .success(function(data) {
        if(data.code ==1) {
          $scope.success = data.status;
        } else {
          $scope.err = data.status;
        }
      });
    }
  }]);

  app.controller('ResetCtrl', ['$scope', '$rootScope', '$http','Auth', '$state', function($scope, $rootScope, $http, Auth, $state) {
    $scope.err = null;
    $scope.success = null;
    if($rootScope.user) {
      $state.go('home');
    }

    $scope.reset = function () {
      Auth.reset($scope.user)
      .success(function(data) {
        if(data.code ==1) {
          $scope.success = data.status;
        } else {
          $scope.err = data.status;
        }
      });
    }
  }]);















