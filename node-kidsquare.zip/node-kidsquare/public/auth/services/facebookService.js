var app = angular.module('facebook.service',[])
.factory('facebookService', function($q) {
    return {
        getInfo: function() {
            var deferred = $q.defer();
            FB.api('/me', {
                fields: ['gender', 'first_name', 'last_name', 'email']
            }, function(response) {
                // if (!response || response.error) {
                //     deferred.reject('Error occured');
                // } else {
                    deferred.resolve(response);
                // }
            });
            return deferred.promise;
        }
    }
});

