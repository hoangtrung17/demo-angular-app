var app = angular.module('auth-state.service',[]);

  // super simple service
  // each function returns a promise object
  var authService = function($http, $rootScope) {
    this.$http = $http;
    this.$rootScope = $rootScope;
    this.user = null;
    this.token = null;
    this.err = null;
  };

  authService.prototype.isAuth = function(data) {
    var _this = this;
    if(data.data.code === 1) {
      _this.user = data.data.user;
      _this.token = data.data.token;
      this.$rootScope.$broadcast('authenticated');
      return true;
    } else {
      _this.err = data.data.message
      this.$rootScope.$broadcast('authenticate-false');
      return false;
    }
  };
  authService.prototype.login = function(user) {
    var _this = this;
    this.$http.post('/api/login', user).then(function(res) {
      _this.isAuth(res);
    });
  };

  authService.prototype.loginFacebook = function(user) {
    var _this = this;
    this.$http.post('/api/callback', user).then(function(res) {
      _this.isAuth(res);
    });
  };

  authService.prototype.regiter = function(user) {
    return this.$http.post('/api/signup', user);
  };
  authService.prototype.forgot = function(email) {
    return this.$http.post('/forgot', {'email':email});
  };
  authService.prototype.logout = function() {
    return this.$http.get('/api/logout');
  };

app.factory('Auth', ['$http', '$rootScope',function($http, $rootScope) {
  return new authService($http, $rootScope);
}]);