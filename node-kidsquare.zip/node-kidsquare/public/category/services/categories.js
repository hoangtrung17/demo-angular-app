var app = angular.module('category.service',[]);

	// super simple service
	// each function returns a promise object
	app.factory('Categories', ['$http', '$rootScope',function($http, $rootScope) {
		return {
			get : function() {

				var req = {
					method: 'GET',
					url: '/api/category',
					headers: {
					  'x-access-token': $rootScope.token
					}
				}
				return $http(req);
			},
			create : function(categoryData) {
				return $http.post('/api/category', categoryData);
			},
			delete : function(id) {
				return $http.delete('/api/category/' + id);
			},
			getPlace: function(categoryId) {
				return $http.get('/api/get/place/' + categoryId);
			},
			createPlace: function(place) {
				return $http.post('/api/place/', place);
			}
		}
	}]);