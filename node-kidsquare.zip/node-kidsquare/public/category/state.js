angular.module('category-state', [
  'category.service',
  'category.controller',
  'dashboard.controler'
  ])

.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
      .state('categories', {
        url: '/categories',
        templateUrl: 'category/views/category.html',
        controller: 'categoryController'
      })
      .state('category-create', {
        url: '/create-category',
        templateUrl: 'category/views/createCategory.html',
        controller: 'createCategoryCtrl'
      })
      .state('categories-place', {
        url: '/place/:categoryId',
        templateUrl: 'category/views/place.html',
        controller: 'placesCtrl'
      })
      .state('create-place', {
        url: '/place/:categoryId',
        templateUrl: 'category/views/createPlace.html',
        controller: 'placeCreateCtrl'
      });
});
