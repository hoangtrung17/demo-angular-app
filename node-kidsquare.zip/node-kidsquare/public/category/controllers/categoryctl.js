var app = angular.module('category.controller',[]);

	app.controller('categoryController', ['$scope', 'Categories', '$rootScope', '$state', 'Auth', function ($scope, Categories, $rootScope, $state, Auth) {
		if(!$rootScope.user) {
	    $state.go('login');
	  }
		$scope.formData = {};
		$scope.loading = true;

		// Get
		// use the service to get all the categories
		Categories.get()
			.success(function(data) {
				$scope.categories = data;
				$scope.loading = false;
			});

		// CREATE
		// when submitting the add form, send the text to the node API
		$scope.createCategory = function() {

			if ($scope.formData.text != undefined) {
				$scope.loading = true;

				Categories.create($scope.formData)
					.success(function(data) {
						$scope.loading = false;
						$scope.formData = {};
						$scope.categories = data;
					});
			}
		};

		// DELETE
		// delete a Category after checking it
		$scope.deleteCategory = function(id) {
			$scope.loading = true;
			Categories.delete(id)
				.success(function(data) {
					$scope.loading = false;
					$scope.categories = data;
				});
		};
	}]);

	app.controller('createCategoryCtrl',['$scope', 'Categories', '$rootScope', '$state', 'Auth', function ($scope, Categories, $rootScope, $state, Auth) {
    if(!$rootScope.user) {
      $state.go('login');
    }

    $scope.create = function() {
      if ($scope.category) {
        Categories.create($scope.category)
          .success(function(data) {
            $scope.categorys = data; // assign our new list of categories
            $state.go('categories');
          });
      }
    };
  }]);

  app.controller('placesCtrl',['$scope', 'Categories', '$rootScope', '$state', '$stateParams', 'Auth', function ($scope, Categories, $rootScope, $state, $stateParams, Auth) {
    if(!$rootScope.user) {
      $state.go('login');
    }
    var categoryId = $stateParams.categoryId;

    Categories.getPlace(categoryId)
    	.success(function(data) {
					$scope.places = data;
					$scope.loading = false;
				});

    $scope.addPlace = function() {
       $state.go('create-place', {'categoryId': $stateParams.categoryId});
      // $state.go('categories');
    };
  }]);

  app.controller('placeCreateCtrl',['$scope', 'Categories', '$rootScope', '$state', '$modal', '$stateParams', 'Auth', function ($scope, Categories, $rootScope, $state, $modal, $stateParams, Auth) {
    if(!$rootScope.user) {
      $state.go('login');
    }
    var categoryId = $stateParams.categoryId;

    $scope.$on('mapInitialized', function(evt, evtMap) {
      map = evtMap;
      $scope.placeMarker = function(e) {
        var marker = new google.maps.Marker({position: e.latLng, map: map});
        $modal.open({
          templateUrl: 'views/modalAddMarker.html',
          controller: 'ModalInstanceCtrl',
          size: '',
          resolve: {
            categoryId: function () {
              return  $stateParams.categoryId;
            },
            lat: function () {
              return e.latLng.H;
            },
            long: function () {
              return e.latLng.L;
            }
          }
        }).result.then(function (place) {
          $scope.place = place;
          Categories.createPlace(place)
          .success(function(data) {
						$scope.places = data;
						$scope.loading = false;
          	map.panTo(e.latLng);
          	 $state.go('categories-place', {'categoryId': $stateParams.categoryId});
					});
        }, function () {
          console.log('Modal dismissed at: ' + new Date());
        });
      }
    });
  }]);














