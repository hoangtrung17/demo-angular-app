angular.module('main-app', [
  'ui.router',
  'ui.bootstrap',
  'ngMap',
  'flash',
  'ngCookies',
  'mp.datePicker',
  'ngMaterial',
  'admin-state',
  'auth-state',
  'category-state',
  'event-state',
  'facebook.service',
  'bootstrap.modal'])
.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
      // HOME STATES AND NESTED VIEWS
      .state('home', {
        url: '/home',
        templateUrl: 'views/home.html',
        controller: ['$rootScope', '$scope', '$modal', function ($rootScope, $scope, $modal) {
          $scope.$on('mapInitialized', function(evt, evtMap) {
            map = evtMap;
            $scope.placeMarker = function(e) {
              var marker = new google.maps.Marker({position: e.latLng, map: map});
              $modal.open({
                templateUrl: 'views/modalAddMarker.html',
                controller: 'ModalInstanceCtrl',
                size: '',
                resolve: {
                  categoryId: function () {
                    return 'truonghoc';
                  },
                  lat: function () {
                    return e.latLng.H;
                  },
                  long: function () {
                    return e.latLng.L;
                  }
                }
              }).result.then(function (place) {
                $scope.place = place;
                map.panTo(e.latLng);
              }, function () {
                console.log('Modal dismissed at: ' + new Date());
              });
            }
          });
        }]
      })
})
.run(function ($rootScope, $cookieStore) {
  $rootScope.$on('$stateChangeStart', function (event, toState, toParams) {
    $rootScope.user = $cookieStore.get('globals') || null;
    $rootScope.token = $cookieStore.get('token') || null;
    var requireLogin = !!$rootScope.user;
    if (requireLogin && typeof $rootScope.user === 'undefined') {
      event.preventDefault();
    }
  });

});