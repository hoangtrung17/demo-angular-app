var mongoose = require('mongoose');

module.exports = mongoose.model('place', {
  categoryId    : {type : String, default: ''},
  latitude      : {type : Number, default: 0},
  longitude     : {type : Number, default: 0},
  imageUrl      : {type : String, default: ''},
  name          : {type : String, default: ''}
});