var mongoose = require('mongoose');

module.exports = mongoose.model('rate', {
  score : {type : Number, default: 0},
  time         : { type: Date, default: Date.now },
  eventId      : {type : String, default: ''},
  userId       : {type : String, default: ''}
});