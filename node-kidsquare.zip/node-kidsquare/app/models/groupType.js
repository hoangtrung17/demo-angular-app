var mongoose = require('mongoose');

module.exports = mongoose.model('groupType', {
  name   : {type : String, default: ''},
  events : [{type : String, default: ''}]
});