// load the things we need
var mongoose = require('mongoose');
var bcrypt   = require('bcrypt-nodejs');

// define the schema for our user model
var userSchema = mongoose.Schema({

    local            : {
      email        : String,
      password     : String,
      savingPoint  : {type : Number, default: 0 },
      isMember     : {type : Boolean, default: false },
      isVIP        : {type : Boolean, default: false },
      isAdmin      : {type : Boolean, default: false },
      isMod        : {type : Boolean, default: false },
      isImplement  : {type : Boolean, default: false },
      birthday     : {type : String, default: '' },
      telephone    : {type : String, default: '' },
      address      : {type : String, default: '' }
    },
    facebook         : {
      id           : String,
      token        : String,
      email        : String,
      name         : String
    },
    twitter          : {
      id           : String,
      token        : String,
      displayName  : String,
      username     : String
    },
    google           : {
      id           : String,
      token        : String,
      email        : String,
      name         : String
    },
    sessionToken : String,
    resetPasswordToken: String,
    resetPasswordExpires: String

});

// generating a hash
userSchema.methods.generateHash = function(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

// checking if password is valid
userSchema.methods.validPassword = function(password) {
    return bcrypt.compareSync(password, this.local.password);
};

// create the model for users and expose it to our app
module.exports = mongoose.model('User', userSchema);
