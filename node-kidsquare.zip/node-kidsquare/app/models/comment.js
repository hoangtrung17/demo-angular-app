var mongoose = require('mongoose');

module.exports = mongoose.model('comment', {
  eventId      : {type : String, default: ''},
  time         : { type: Date, default: Date.now },
  description  : {type : String, default: ''},
  userId       : {type : String, default: ''}
});