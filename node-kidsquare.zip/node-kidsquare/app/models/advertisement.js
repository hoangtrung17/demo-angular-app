var mongoose = require('mongoose');

module.exports = mongoose.model('advertisements', {
	name         : {type : String, default: ''},
	description  : {type : String, default: ''},
	images       : [{type : String, default: ''}]
});