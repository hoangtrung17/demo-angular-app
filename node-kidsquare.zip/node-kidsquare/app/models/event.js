var mongoose = require('mongoose');

module.exports = mongoose.model('events', {
  placeId      : {type : String},
	groupType    : {type : String, default: ''},
	name         : {type : String, default: ''},
	description  : {type : String, default: ''},
	startDate     : { type: Date, default: Date.now },
	enDate       : { type: Date, default: Date.now },
	image        : {type : String, default: ''},
	rate         : {type : Number, default: 0},
	comments		 : 	[{ body: String, date: Date }]
});