var Place    = require('../models/place');;
var express  = require('express');
var router   = express.Router();

  // middleware specific to this router
  router.use(function timeLog(req, res, next) {
    console.log('Time: ', Date.now());
    next();
  });

  function getPlaces(res){
    Place.find(function(err, places) {
      if (err)
        res.send(err)
      res.json(places);
    });
  };

  // get all Place
  router.get('/', function(req, res) {
    // use mongoose to get all Places in the database
      // if there is an error retrieving, send the error. nothing after res.send(err) will execute
    getPlaces(res);
  });

  // create Place and send back all Places after creation
  router.post('/', function(req, res) {
    var categoryId = '';
    if(req.body.categoryId) {
      categoryId = req.body.categoryId;
    }

    Place.create({
      name        : req.body.name,
      categoryId  : categoryId,
      latitude    : req.body.latitude,
      longitude   : req.body.longitude,
      imageUrl    : req.body.imageUrl

    }, function(err, place) {
      if (err)
        res.send(err);
      // get and return all the Places after you create another
      getPlaces(res);
    });

  });

  // delete a Place
  router.delete('/:_id', function(req, res) {
    Place.remove({
      _id : req.params._id
    }, function(err, place) {
      if (err)
        res.send(err);

      getPlaces(res);
    });
  });

module.exports = router;