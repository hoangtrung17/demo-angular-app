var Event    = require('../models/event');
var Place    = require('../models/place');
var Category    = require('../models/category');
var express  = require('express');
var router   = express.Router();

  // middleware specific to this router
  router.use(function timeLog(req, res, next) {
    console.log('Time: ', Date.now());
    next();
  });
  // get all event
  router.get('/event', function(req, res) {
    // use mongoose to get all events in the database
    Event.find(function(err, events) {
      // if there is an error retrieving, send the error. nothing after res.send(err) will execute
      if (err)
        res.send(err)
      res.json(events); // return all events in JSON format
    });
  });

  router.get('/category', function(req, res) {
    // use mongoose to get all category in the database
    Category.find(function(err, data) {
      // if there is an error retrieving, send the error. nothing after res.send(err) will execute
      if (err)
        res.send(err)
      res.json(data); // return all category in JSON format
    });
  });

  router.get('/place', function(req, res) {
    // use mongoose to get all places in the database
    Place.find(function(err, places) {
      // if there is an error retrieving, send the error. nothing after res.send(err) will execute
      if (err)
        res.send(err)
      res.json(places); // return all places in JSON format
    });
  });

  router.get('/place/:_categoryId', function(req, res) {
    // use mongoose to get all places in the database
    Place.find({categoryId:req.params._categoryId}, function(err, places) {
      // if there is an error retrieving, send the error. nothing after res.send(err) will execute
      if (err)
        res.send(err)
      res.json(places); // return all places in JSON format
    });
  });

module.exports = router;