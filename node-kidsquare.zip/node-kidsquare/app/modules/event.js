var Event    = require('../models/event');
var express  = require('express');
var router   = express.Router();

	// middleware specific to this router
	router.use(function timeLog(req, res, next) {
	  console.log('Time: ', Date.now());
	  next();
	});

	function getEvents(res){
		Event.find(function(err, events) {
			// if there is an error retrieving, send the error. nothing after res.send(err) will execute
			if (err)
				res.send(err)
			res.json(events); // return all events in JSON format
		});
	};

	// get all event
	router.get('/', function(req, res) {
		// use mongoose to get all events in the database
		getEvents(res);
	});

	// create event and send back all events after creation
	router.post('/', function(req, res) {
		// create a event, information comes from AJAX request from Angular
		Event.create({
			name : req.body.name,
			// groupType    : req.body.groupType,
			description  : req.body.description,
			startDate     : req.body.startDate,
			enDate       : req.body.enDate,
			image       : req.body.image
		}, function(err, event) {
			if (err)
				res.send(err);
			// get and return all the events after you create another
			getEvents(res);
		});

	});

	// delete a event
	router.delete('/:_id', function(req, res) {
		Event.remove({
			_id : req.params._id
		}, function(err, event) {
			if (err)
				res.send(err);

			getEvents(res);
		});
	});

module.exports = router;