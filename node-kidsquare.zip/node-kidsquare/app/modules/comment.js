var Comment    = require('../models/comment');;
var express  = require('express');
var router   = express.Router();

  // middleware specific to this router
  router.use(function timeLog(req, res, next) {
    console.log('Time: ', Date.now());
    next();
  });

  function getComments(res){
    Comment.find(function(err, comments) {
      if (err)
        res.send(err)
      res.json(comments);
    });
  };

  // get all Comment
  router.get('/', function(req, res) {
    // use mongoose to get all Comments in the database
      // if there is an error retrieving, send the error. nothing after res.send(err) will execute
    getComments(res);
  });

  // create Comment and send back all Comments after creation
  router.post('/', function(req, res) {

    Comment.create({
      eventId      : req.body.eventId,
      time         : req.body.time,
      description  : req.body.description,
      userId       : req.body.userId

    }, function(err, comment) {
      if (err)
        res.send(err);
      // get and return all the Comments after you create another
      getComments(res);
    });

  });

  // delete a Comment
  router.delete('/:_id', function(req, res) {
    Comment.remove({
      _id : req.params._id
    }, function(err, comment) {
      if (err)
        res.send(err);

      getComments(res);
    });
  });

module.exports = router;