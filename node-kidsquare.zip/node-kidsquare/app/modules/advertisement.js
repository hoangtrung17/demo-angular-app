var Advertisement   = require('../models/advertisement.js');
var express  = require('express');
var router   = express.Router();

	// middleware specific to this router
	router.use(function timeLog(req, res, next) {
	  console.log('Time: ', Date.now());
	  next();
	});

	function getAdvertisements(res){
		Advertisement.find(function(err, advertisements) {
			if (err) {
				res.send(err)
			}
			res.json(advertisements); // return all advertisements in JSON format
		});
	};

	// get all advertisement
	router.get('/', function(req, res) {
		// use mongoose to get all Advertisements in the database
		getAdvertisements(res);
	});

	// create advertisement and send back all Advertisements after creation
	router.post('/', function(req, res) {
		Advertisement.create({
			name 					: req.body.name,
			description  : req.body.description,
			image       : req.body.image
		}, function(err, advertisement) {
			if (err)
				res.send(err);
			// get and return all the Advertisements after you create another
			getAdvertisements(res);
		});

	});

	// delete a Advertisement
	router.delete('/:_id', function(req, res) {
		Advertisement.remove({
			_id : req.params._id
		}, function(err, advertisement) {
			if (err)
				res.send(err);
			getAdvertisements(res);
		});
	});

module.exports = router;