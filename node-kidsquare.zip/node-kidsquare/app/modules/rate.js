var Rate    = require('../models/rate');;
var express  = require('express');
var router   = express.Router();

  // middleware specific to this router
  router.use(function timeLog(req, res, next) {
    console.log('Time: ', Date.now());
    next();
  });

  function getRates(res){
    Rate.find(function(err, rates) {
      if (err)
        res.send(err)
      res.json(rates);
    });
  };

  // get all rate
  router.get('/', function(req, res) {
    // use mongoose to get all Rates in the database
      // if there is an error retrieving, send the error. nothing after res.send(err) will execute
    getRates(res);
  });

  // create rate and send back all Rates after creation
  router.post('/', function(req, res) {

    Rate.create({
      score   : req.body.score,
      time    : req.body.time,
      eventId : req.body.eventId,
      userId  : req.body.userId

    }, function(err, rate) {
      if (err)
        res.send(err);
      // get and return all the Rates after you create another
      getRates(res);
    });

  });

  // delete a rate
  router.delete('/:_id', function(req, res) {
    Rate.remove({
      _id : req.params._id
    }, function(err, rate) {
      if (err)
        res.send(err);

      getRates(res);
    });
  });

module.exports = router;