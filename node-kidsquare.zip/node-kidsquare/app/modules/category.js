var Category = require('../models/category');
var express  = require('express');
var router   = express.Router();

	router.use(function timeLog(req, res, next) {
	  console.log('Time: ', Date.now());
	  next();
	});

	function getCategories(res){
		Category.find(function(err, categories) {
			// if there is an error retrieving, send the error. nothing after res.send(err) will execute
			if (err){
				res.send(err)
			}
			res.json(categories); // return all categoies in JSON format
		});
	};


	// get all categoies
	router.get('/', function(req, res) {
		// use mongoose to get all categoies in the database
		getCategories(res);
	});

	// create todo and send back all categoies after creation
	router.post('/', function(req, res) {
		// create a todo, information comes from AJAX request from Angular
		Category.create({
			name : req.body.name,
			places    : []
		}, function(err, todo) {
			if (err)
				res.send(err);
			// get and return all the categoies after you create another
			getCategories(res);
		});

	});

	// delete a todo
	router.delete('/:category_id', function(req, res) {
		Category.remove({
			_id : req.params.category_id
		}, function(err, category) {
			if (err)
				res.send(err);

			getCategories(res);
		});
	});

module.exports = router;

