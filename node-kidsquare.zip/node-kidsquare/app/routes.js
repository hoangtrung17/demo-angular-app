
var User                  = require('./models/user');
var Mailgun               = require('mailgun').Mailgun;
var nodemailer            = require('nodemailer');
var LocalStrategy         = require('passport-local').Strategy;
var bcrypt                = require('bcrypt-nodejs');
var async                 = require('async');
var crypto                = require('crypto');
var flash                 = require('connect-flash');
var eventModule           = require('./modules/event');
var advertisementModule   = require('./modules/advertisement');
var categoryModule        = require('./modules/category');
var placeModule           = require('./modules/place');
var commentModule         = require('./modules/comment');
var rateModule            = require('./modules/rate');
var getModule             = require('./modules/getData');
var jwt                   = require('jsonwebtoken');


module.exports = function(app, passport) {
  // app.use(isLoggedIn);
  app.use('/api/advertisements', isLoggedIn );
  app.use('/api/event', isLoggedIn);
  app.use('/api/category', isLoggedIn);
  app.use('/api/advertisements', advertisementModule);
  app.use('/api/event', eventModule);
  app.use('/api/category', categoryModule);
  app.use('/api/place', placeModule);
  app.use('/api/comment', commentModule);
  app.use('/api/rate', rateModule);
  app.use('/api/get', getModule);
  app.set('superSecret', 'ilovekidsquare');


	// normal routes ===============================================================
  // show the home page (will also have our login links)
  app.get('/', function(req, res) {
    res.sendfile('./public/index.html');
  });

  // PROFILE SECTION =========================
  app.get('/profile', isLoggedIn, function(req, res) {
    res.render('home.html', {
      user : req.user
    });
  });

  // LOGOUT ==============================
  app.get('/logout', function(req, res) {
    req.logout();
    res.redirect('/');
  });

  app.get('/api/logout', function(req, res) {
    req.logout();
    return res.json({'status':'Signed out', 'code': -1});
  });

  // LOGIN ===============================
  // show the login form
  app.get('/login', function(req, res) {
    res.render('auth/login.html');
  });

  // process the login form
  app.post('/login', passport.authenticate('local-login', {
    successRedirect : '/profile', // redirect to the secure profile section
    failureRedirect : '/', // redirect back to the signup page if there is an error
    failureFlash : true // allow flash messages
  }));

   // process the login for mobile
  app.post('/api/login', passport.authenticate('local-login', {
    successRedirect : '/signined', // redirect to the secure profile section
    failureRedirect : '/signinfail', // redirect back to the signup page if there is an error
    failureFlash : true // allow flash messages
  }));

  // show the signup form
  app.get('/signup', function(req, res) {
    res.render('auth/register.html');
  });

  // process the signup form
  app.post('/signup', passport.authenticate('local-signup', {
    successRedirect : '/home', // redirect to the secure profile section
    failureRedirect : '/signup', // redirect back to the signup page if there is an error
    failureFlash : true // allow flash messages
  }));

  // process the signup form
  app.post('/api/signup', passport.authenticate('local-signup', {
    successRedirect : '/signined', // redirect to the secure profile section
    failureRedirect : '/signinfail', // redirect back to the signup page if there is an error
    failureFlash : true // allow flash messages
  }));

  app.get('/signined', function(req,res) {
    // create a token
    var exp = { expires : Date.now() + 24*3600000,
                user: res.req.user }
    var token = jwt.sign(exp, app.get('superSecret'), {
      expiresInMinutes: 1440 // expires in 24 hours
    });

    res.json({"status":"Authenticated", "code":1, "user": res.req.user, "token": token});
  });

  app.post('/api/callback', function(req,res) {
    // create a token
    var exp = { expires : Date.now() + 24*3600000,
                user: req.body }
    var token = jwt.sign(exp, app.get('superSecret'), {
      expiresInMinutes: 1440 // expires in 24 hours
    });

    res.json({"status":"Authenticated", "code":1, "user": req.body, "token": token});
  });

  app.post('/forgot', function(req, res, next) {
    async.waterfall([
      function(done) {
        crypto.randomBytes(20, function(err, buf) {
          var token = buf.toString('hex');
          done(err, token);
        });
      },
      function(token, done) {
        User.findOne({ 'local.email': req.body.email }, function(err, user) {
          if (!user) {
            req.flash('error', 'No account with that email address exists.');
            return res.json({"status":"No account with that email address exists.", "code":8});
          }
          user.resetPasswordToken = token;
          user.resetPasswordExpires = Date.now() + 3600000; // 1 hour

          user.save(function(err) {
            done(err, token, user);
          });
        });
      },
      function(token, user, done) {
        var mg = new Mailgun('key-f1791b53b5e695d101fedab980396838');
        mg.sendText('admin@kidsquare.com', [user.local.email],
          'Xác nhận yêu cầu lấy lại mật khẩu',
          'Bạn nhận được emmail này bởi vì bạn (hoặc ai đó) yêu cầu reset lại mật khẩu từ tài khoản Kidsquare của bạn.\n\n' +
            'Nếu đây là bạn click vào đường link bên dưới để tiếp tục:\n\n' +
            'http://' + req.headers.host + '/reset/' + token + '\n\n' +
            'Nếu đây không phải là bạn thì hãy bỏ qua email này và tài khoảng của bạn sẽ không có gì thay đổi.\n',
          'admin@kidsquare.com', {},
          function(err) {
            done(err, 'done');
        });
      }
    ], function(err) {
      if (err) {
        res.json({"status":"Reset password not success.", "code":8});
      }
      return res.json({"status":"Vui lòng kiểm tra email để cài đặt lại mật khẩu cho tài khoản của bạn", "code":1});
    });
  });

  app.get('/reset/:token', function(req, res) {
    res.render('auth/reset.html');
  });

  app.post('/reset/:token', function(req, res) {
    async.waterfall([
      function(done) {
        User.findOne({ 'resetPasswordToken': req.params.token}, function(err, user) {
          if (!user) {
            req.flash('error', 'Password reset token is invalid or has expired.');
            return res.redirect('back');
          }
          user.local.password = user.generateHash(req.body.password);
          user.resetPasswordToken = undefined;
          user.resetPasswordExpires = undefined;

          user.save(function(err) {
            req.logIn(user, function(err) {
              done(err, user);
            });
          });
        });
      },
      function(user, done) {
        var mg = new Mailgun('key-f1791b53b5e695d101fedab980396838');
        mg.sendText('admin@kidsquare.com', ['dungle2048@gmail.com'],
          'Thay đổi mật khẩu thành công',
          'Mật khẩu của bạn được thay đổi thành công click vào đường link bên dưới để tiếp tục:\n\n' +
            'http://' + req.headers.host + '/' + '\n',
          'admin@kidsquare.com', {},
          function(err) {
            done(err, 'done');
        });

      }
    ], function(err) {
      if(err) {
        return res.json({"status":"No account with that token exists.", "code":9});
      }
      return res.json({"status":"Reset password thành công.", "code":1});
    });
  });


  // facebook -------------------------------
  // send to facebook kidsquare the authentication
  app.get('/auth/facebook', passport.authenticate('facebook', { scope : ['email'] }));

  // handle the callback after facebook has authenticated the user
  app.get('/auth/facebook/callback',
    passport.authenticate('facebook', {
        successRedirect : '/signined',
        failureRedirect : '/'
    }));

    // locally --------------------------------
        app.get('/connect/local', function(req, res) {
          res.render('connect-local.ejs', { message: req.flash('loginMessage') });
        });
        app.post('/connect/local', passport.authenticate('local-signup', {
          successRedirect : '/profile', // redirect to the secure profile section
          failureRedirect : '/connect/local', // redirect back to the signup page if there is an error
          failureFlash : true // allow flash messages
        }));

    // facebook -------------------------------

        // send to facebook kidsquare the authentication
        app.get('/connect/facebook', passport.authorize('facebook', { scope : 'email' }));

        // handle the callback after facebook has authorized the user
        app.get('/connect/facebook/callback',
          passport.authorize('facebook', {
              successRedirect : '/profile',
              failureRedirect : '/'
          }));


    // local -----------------------------------
    /**
     * @return redirect to /profile
     * @description :  Used to unlink accounts. for social accounts, just remove the token
     * for local account, remove email and password
     * user account will stay active in case they want to reconnect in the future
     */
    app.get('/unlink/local', isLoggedIn, function(req, res) {
      var user            = req.user;
      user.local.email    = undefined;
      user.local.password = undefined;
      user.save(function(err) {
          res.redirect('/profile');
      });
    });

    // facebook -------------------------------
    app.get('/unlink/facebook', isLoggedIn, function(req, res) {
      var user            = req.user;
      user.facebook.token = undefined;
      user.save(function(err) {
          res.redirect('/profile');
      });
    });

    function getUser(req, res) {
      User.find(function(err, users) {
        if (err) {
          return res.json({"status":"Not found data", "code":8});
        }

        var listUser = [];
        for (var i = users.length - 1; i >= 0; i--) {
          if(users[i].local && users[i]._id !== req.params.id) {
            listUser.push(users[i]);
          }
        };
        return res.json(listUser);
      });
    }

    app.get('/users/:id', function(req, res, next) {
      getUser(req, res);
    });

    app.post('/setrole/:id', function(req, res, next) {
      User.findOne({ 'local.email': req.body.local.email }, function(err, user) {
        if (!user.local) {
          req.flash('error', 'No account with that email address exists.');
          return res.json({"status":"No account with that email address exists.", "code":8});
        }

        user.local.isAdmin = req.body.local.isAdmin;
        user.local.isMember = req.body.local.isMember;
        user.local.isVIP = req.body.local.isVIP;
        user.local.isImplement = req.body.local.isImplement;
        user.local.isMod = req.body.local.isMod;

        // user.visits.$inc();
        user.save(function(err, doc) {
          if(err) {
            return res.send(400);
          }
          getUser(req, res);
        });
      });
    });

	// route middleware to ensure user is logged in
	function isLoggedIn(req, res, next) {
     // check header or url parameters or post parameters for token
    var token = req.body.token || req.query.token || req.headers['x-access-token'];
    // decode token
    if (token) {
      // verifies secret and checks exp
      jwt.verify(token, app.get('superSecret'), function(err, decoded) {
        if (err) {
          return res.json({ success: false, message: 'Failed to authenticate token.', code: 5});
        } else {
          // if token timeout
          if(Date.now() > decoded.expires || !decoded.expires ) {
            return res.json({ success: false, message: 'Token timeout !', code: 6 });
          }
          return next();
        }
      });
    } else {
      if (req.isAuthenticated()) {
        return next();
      }
      // if there is no token
      // return an error
      return res.status(403).send({
        success: false,
        message: 'No token provided.'
      });
    }
	}
};